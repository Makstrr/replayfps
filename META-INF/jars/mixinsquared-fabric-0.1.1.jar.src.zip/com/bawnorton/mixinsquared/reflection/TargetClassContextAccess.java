/*    */ package com.bawnorton.mixinsquared.reflection;
/*    */ 
/*    */ import java.util.SortedSet;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;
/*    */ 
/*    */ 
/*    */ public final class TargetClassContextAccess
/*    */ {
/*    */   public static SortedSet<IMixinInfo> getMixins(ITargetClassContext context) {
/* 11 */     return Reflection.<SortedSet<IMixinInfo>>accessField(context, "mixins", (Class)SortedSet.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\reflection\TargetClassContextAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */