/*    */ package com.bawnorton.mixinsquared.reflection;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public abstract class Reflection
/*    */ {
/*    */   public static <T> T accessField(Object instance, String fieldName, Class<T> fieldType) {
/*    */     try {
/*  9 */       Field field = instance.getClass().getDeclaredField(fieldName);
/* 10 */       field.setAccessible(true);
/* 11 */       return fieldType.cast(field.get(instance));
/* 12 */     } catch (NoSuchFieldException|IllegalAccessException e) {
/* 13 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\reflection\Reflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */