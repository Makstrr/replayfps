/*    */ package com.bawnorton.mixinsquared.reflection;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.Extensions;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.IExtension;
/*    */ 
/*    */ 
/*    */ public final class ExtensionsAccess
/*    */ {
/*    */   public static List<IExtension> getExtensions(Extensions instance) {
/* 12 */     return Reflection.<List<IExtension>>accessField(instance, "extensions", (Class)List.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Map<Class<? extends IExtension>, IExtension> getExtensionMap(Extensions instance) {
/* 17 */     return Reflection.<Map<Class<? extends IExtension>, IExtension>>accessField(instance, "extensionMap", (Class)Map.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\reflection\ExtensionsAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */