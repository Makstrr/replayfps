/*     */ package com.bawnorton.mixinsquared.selector;
/*     */ 
/*     */ import com.bawnorton.mixinsquared.TargetHandler;
/*     */ import org.objectweb.asm.tree.AnnotationNode;
/*     */ import org.objectweb.asm.tree.MethodNode;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.ElementNode;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.ISelectorContext;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.ITargetSelector;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.ITargetSelectorDynamic;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.ITargetSelectorDynamic.SelectorId;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.InvalidSelectorException;
/*     */ import org.spongepowered.asm.mixin.injection.selectors.MatchResult;
/*     */ import org.spongepowered.asm.mixin.transformer.meta.MixinMerged;
/*     */ import org.spongepowered.asm.util.Annotations;
/*     */ import org.spongepowered.asm.util.PrettyPrinter;
/*     */ import org.spongepowered.asm.util.asm.IAnnotatedElement;
/*     */ import org.spongepowered.asm.util.asm.MethodNodeEx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SelectorId("Handler")
/*     */ public final class DynamicSelectorHandler
/*     */   implements ITargetSelectorDynamic
/*     */ {
/*     */   private final String mixinName;
/*     */   private final String name;
/*     */   private final String prefix;
/*     */   private final boolean print;
/*  47 */   private final PrettyPrinter printer = new PrettyPrinter();
/*     */   
/*     */   public DynamicSelectorHandler(String mixinName, String name, String prefix, boolean print) {
/*  50 */     this.mixinName = mixinName;
/*  51 */     this.name = name;
/*  52 */     this.prefix = (prefix == null) ? null : (prefix.isEmpty() ? null : prefix);
/*  53 */     this.print = print;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynamicSelectorHandler parse(String input, ISelectorContext context) {
/*     */     AnnotationNode annotationNode;
/*  60 */     if (context.getMethod() instanceof MethodNode) {
/*  61 */       MethodNode method = (MethodNode)context.getMethod();
/*  62 */       annotationNode = Annotations.getVisible(method, TargetHandler.class);
/*  63 */     } else if (context.getMethod() instanceof IAnnotatedElement) {
/*  64 */       IAnnotatedElement element = (IAnnotatedElement)context.getMethod();
/*  65 */       annotationNode = (AnnotationNode)element.getAnnotation(TargetHandler.class).getValue();
/*     */     } else {
/*  67 */       throw new AssertionError("Could not get annotation for method");
/*     */     } 
/*  69 */     return new DynamicSelectorHandler((String)Annotations.getValue(annotationNode, "mixin"), (String)Annotations.getValue(annotationNode, "name"), (String)Annotations.getValue(annotationNode, "prefix", ""), ((Boolean)Annotations.getValue(annotationNode, "print", Boolean.FALSE)).booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public ITargetSelector next() {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITargetSelector configure(ITargetSelector.Configure request, String... args) {
/*  79 */     return (ITargetSelector)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITargetSelector validate() throws InvalidSelectorException {
/*  84 */     return (ITargetSelector)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITargetSelector attach(ISelectorContext context) throws InvalidSelectorException {
/*  89 */     if (context.getMixin().getClassName().equals(this.mixinName)) {
/*  90 */       throw new InvalidSelectorException("Dynamic selector targets self!");
/*     */     }
/*  92 */     if (this.print) {
/*  93 */       this.printer.kvWidth(20)
/*  94 */         .kv("Mixin", this.mixinName)
/*  95 */         .kv("Name", this.name)
/*  96 */         .kv("Prefix", this.prefix)
/*  97 */         .add("%100s %-15s %-50s %s", new Object[] { "MIXIN", "PREFIX", "ORIGINAL NAME", "CANDIDATE"
/*  98 */           }).print(System.err);
/*     */     }
/* 100 */     return (ITargetSelector)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinMatchCount() {
/* 105 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxMatchCount() {
/* 110 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public <TNode> MatchResult match(ElementNode<TNode> node) {
/* 115 */     MethodNode method = node.getMethod();
/* 116 */     AnnotationNode annotation = Annotations.getVisible(method, MixinMerged.class);
/* 117 */     if (annotation == null) return MatchResult.NONE; 
/* 118 */     if (!(method instanceof MethodNodeEx)) return MatchResult.NONE;
/*     */     
/* 120 */     MethodNodeEx methodNodeEx = (MethodNodeEx)method;
/* 121 */     String targetMixinName = (String)Annotations.getValue(annotation, "mixin");
/* 122 */     MatchResult result = matchInternal(targetMixinName, methodNodeEx);
/* 123 */     if (this.print)
/* 124 */       System.err.printf("/* %100s %-15s %-50s %9s */\n", new Object[] { targetMixinName, method.name.split("\\$")[0], methodNodeEx.getOriginalName(), result.isExactMatch() ? "YES" : "-" }); 
/* 125 */     return result;
/*     */   }
/*     */   
/*     */   private MatchResult matchInternal(String targetMixinName, MethodNodeEx method) {
/* 129 */     if (!this.mixinName.equals(targetMixinName)) return MatchResult.NONE; 
/* 130 */     if (this.prefix != null) {
/* 131 */       String methodPrefix = method.name.split("\\$")[0];
/* 132 */       if (!methodPrefix.equalsIgnoreCase(this.prefix)) return MatchResult.NONE; 
/*     */     } 
/* 134 */     if (method.getOriginalName().equals(this.name)) {
/* 135 */       return MatchResult.EXACT_MATCH;
/*     */     }
/* 137 */     if (method.getOriginalName().equalsIgnoreCase(this.name)) {
/* 138 */       return MatchResult.MATCH;
/*     */     }
/* 140 */     return MatchResult.NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 145 */     return "@MixinSquared:Handler[mixin='" + this.mixinName + '\'' + ", name='" + this.name + '\'' + ", prefix='" + this.prefix + '\'' + ']';
/*     */   }
/*     */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\selector\DynamicSelectorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */