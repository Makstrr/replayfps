/*    */ package com.bawnorton.mixinsquared;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.annotation.processing.AbstractProcessor;
/*    */ import javax.annotation.processing.ProcessingEnvironment;
/*    */ import javax.annotation.processing.RoundEnvironment;
/*    */ import javax.annotation.processing.SupportedAnnotationTypes;
/*    */ import javax.lang.model.SourceVersion;
/*    */ import javax.lang.model.element.TypeElement;
/*    */ import org.spongepowered.asm.util.logging.MessageRouter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @SupportedAnnotationTypes({})
/*    */ public final class MixinSquaredAnnotationProcessor
/*    */   extends AbstractProcessor
/*    */ {
/*    */   public SourceVersion getSupportedSourceVersion() {
/* 41 */     return SourceVersion.latestSupported();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void init(ProcessingEnvironment processingEnv) {
/* 46 */     super.init(processingEnv);
/*    */     try {
/* 48 */       MessageRouter.setMessager(processingEnv.getMessager());
/* 49 */       MixinSquaredBootstrap.init(false);
/* 50 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
/* 56 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\MixinSquaredAnnotationProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */