package com.bawnorton.mixinsquared.api;

import java.util.List;

public interface MixinCanceller {
  boolean shouldCancel(List<String> paramList, String paramString);
}


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\api\MixinCanceller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */