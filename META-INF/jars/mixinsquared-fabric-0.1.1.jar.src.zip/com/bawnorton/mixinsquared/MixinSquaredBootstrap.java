/*    */ package com.bawnorton.mixinsquared;
/*    */ 
/*    */ import com.bawnorton.mixinsquared.canceller.ExtensionCancelApplication;
/*    */ import com.bawnorton.mixinsquared.canceller.ExtensionRegistrar;
/*    */ import com.bawnorton.mixinsquared.selector.DynamicSelectorHandler;
/*    */ import org.spongepowered.asm.mixin.injection.selectors.TargetSelector;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.IExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MixinSquaredBootstrap
/*    */ {
/*    */   public static final String NAME = "mixinsquared";
/*    */   public static final String VERSION = "0.1.0";
/*    */   private static boolean initialized = false;
/*    */   
/*    */   public static void init() {
/* 39 */     init(true);
/*    */   }
/*    */   
/*    */   static void init(boolean runtime) {
/* 43 */     if (initialized)
/*    */       return; 
/* 45 */     initialized = true;
/*    */     
/* 47 */     TargetSelector.register(DynamicSelectorHandler.class, "MixinSquared");
/*    */     
/* 49 */     if (runtime)
/* 50 */       ExtensionRegistrar.register((IExtension)new ExtensionCancelApplication()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\MixinSquaredBootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */