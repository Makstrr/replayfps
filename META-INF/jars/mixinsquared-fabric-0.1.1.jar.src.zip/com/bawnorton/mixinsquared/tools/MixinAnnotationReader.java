/*    */ package com.bawnorton.mixinsquared.tools;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.objectweb.asm.Type;
/*    */ import org.objectweb.asm.tree.AnnotationNode;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.service.IClassBytecodeProvider;
/*    */ import org.spongepowered.asm.service.MixinService;
/*    */ import org.spongepowered.asm.util.Annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MixinAnnotationReader
/*    */ {
/*    */   public MixinAnnotationReader(String mixinClassName) {
/*    */     try {
/* 21 */       ClassNode classNode = bytecodeProvider.getClassNode(mixinClassName);
/* 22 */       this.mixinAnnotation = Annotations.getInvisible(classNode, Mixin.class);
/* 23 */     } catch (ClassNotFoundException|java.io.IOException e) {
/* 24 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public MixinAnnotationReader(ClassNode mixinClassNode) {
/* 29 */     this.mixinAnnotation = Annotations.getInvisible(mixinClassNode, Mixin.class);
/*    */   }
/*    */ 
/*    */   
/* 33 */   private static final IClassBytecodeProvider bytecodeProvider = MixinService.getService().getBytecodeProvider();
/*    */   private final AnnotationNode mixinAnnotation;
/*    */   
/*    */   public List<Type> getValue() {
/* 37 */     return (List<Type>)Annotations.getValue(this.mixinAnnotation, "value", Collections.emptyList());
/*    */   }
/*    */   
/*    */   public List<String> getTargets() {
/* 41 */     return (List<String>)Annotations.getValue(this.mixinAnnotation, "targets", Collections.emptyList());
/*    */   }
/*    */   
/*    */   public int getPriority() {
/* 45 */     return ((Integer)Annotations.getValue(this.mixinAnnotation, "priority", Integer.valueOf(1000))).intValue();
/*    */   }
/*    */   
/*    */   public boolean getRemap() {
/* 49 */     return ((Boolean)Annotations.getValue(this.mixinAnnotation, "remap", Boolean.TRUE)).booleanValue();
/*    */   }
/*    */   
/*    */   public static List<Type> getValue(String mixinClassName) {
/* 53 */     return (new MixinAnnotationReader(mixinClassName)).getValue();
/*    */   }
/*    */   
/*    */   public static List<String> getTargets(String mixinClassName) {
/* 57 */     return (new MixinAnnotationReader(mixinClassName)).getTargets();
/*    */   }
/*    */   
/*    */   public static int getPriority(String mixinClassName) {
/* 61 */     return (new MixinAnnotationReader(mixinClassName)).getPriority();
/*    */   }
/*    */   
/*    */   public static boolean getRemap(String mixinClassName) {
/* 65 */     return (new MixinAnnotationReader(mixinClassName)).getRemap();
/*    */   }
/*    */   
/*    */   public static List<Type> getValue(ClassNode mixinClassNode) {
/* 69 */     return (new MixinAnnotationReader(mixinClassNode)).getValue();
/*    */   }
/*    */   
/*    */   public static List<String> getTargets(ClassNode mixinClassNode) {
/* 73 */     return (new MixinAnnotationReader(mixinClassNode)).getTargets();
/*    */   }
/*    */   
/*    */   public static int getPriority(ClassNode mixinClassNode) {
/* 77 */     return (new MixinAnnotationReader(mixinClassNode)).getPriority();
/*    */   }
/*    */   
/*    */   public static boolean getRemap(ClassNode mixinClassNode) {
/* 81 */     return (new MixinAnnotationReader(mixinClassNode)).getRemap();
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\tools\MixinAnnotationReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */