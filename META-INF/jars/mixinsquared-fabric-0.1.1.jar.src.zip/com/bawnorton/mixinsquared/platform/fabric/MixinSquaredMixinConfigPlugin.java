/*    */ package com.bawnorton.mixinsquared.platform.fabric;
/*    */ 
/*    */ import com.bawnorton.mixinsquared.MixinSquaredBootstrap;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MixinSquaredMixinConfigPlugin
/*    */   implements IMixinConfigPlugin
/*    */ {
/*    */   public void onLoad(String mixinPackage) {
/* 43 */     MixinSquaredBootstrap.init();
/* 44 */     MixinCancellerLoader.load();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRefMapperConfig() {
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
/* 54 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getMixins() {
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */   
/*    */   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\platform\fabric\MixinSquaredMixinConfigPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */