/*   */ package com.bawnorton.mixinsquared.platform.fabric;
/*   */ import com.bawnorton.mixinsquared.api.MixinCanceller;
/*   */ import com.bawnorton.mixinsquared.canceller.MixinCancellerRegistrar;
/*   */ import net.fabricmc.loader.api.FabricLoader;
/*   */ import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
/*   */ 
/*   */ public final class MixinCancellerLoader {
/*   */   public static void load() {
/* 9 */     FabricLoader.getInstance().getEntrypointContainers("mixinsquared", MixinCanceller.class).forEach(container -> {
/*   */           String id = container.getProvider().getMetadata().getId();
/*   */           try {
/*   */             MixinCanceller canceller = (MixinCanceller)container.getEntrypoint();
/*   */             MixinCancellerRegistrar.register(canceller);
/* > */           } catch (Throwable e) {
/*   */             System.err.printf("Mod %s provides a broken MixinCanceller implementation:\n", new Object[] { id });
/*   */             e.printStackTrace(System.err);
/*   */           } 
/*   */         });
/*   */   }
/*   */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\platform\fabric\MixinCancellerLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */