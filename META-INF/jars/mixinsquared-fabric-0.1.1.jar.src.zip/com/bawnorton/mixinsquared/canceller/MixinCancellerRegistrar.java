/*    */ package com.bawnorton.mixinsquared.canceller;
/*    */ 
/*    */ import com.bawnorton.mixinsquared.api.MixinCanceller;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.spongepowered.asm.logging.ILogger;
/*    */ import org.spongepowered.asm.service.MixinService;
/*    */ 
/*    */ public abstract class MixinCancellerRegistrar
/*    */ {
/* 12 */   private static final Set<MixinCanceller> cancellers = new HashSet<>();
/* 13 */   private static final ILogger LOGGER = MixinService.getService().getLogger("mixinsquared");
/*    */   
/*    */   public static boolean shouldCancel(List<String> targetClassNames, String mixinClassName) {
/* 16 */     return cancellers.stream().anyMatch(canceller -> canceller.shouldCancel(targetClassNames, mixinClassName));
/*    */   }
/*    */   
/*    */   public static void register(MixinCanceller canceller) {
/* 20 */     cancellers.add(canceller);
/* 21 */     LOGGER.debug("Registered canceller {}", new Object[] { canceller.getClass().getName() });
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\canceller\MixinCancellerRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */