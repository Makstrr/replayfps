/*    */ package com.bawnorton.mixinsquared.canceller;
/*    */ 
/*    */ import com.bawnorton.mixinsquared.reflection.ExtensionsAccess;
/*    */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*    */ import org.spongepowered.asm.mixin.transformer.IMixinTransformer;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.Extensions;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.IExtension;
/*    */ 
/*    */ public abstract class ExtensionRegistrar {
/*    */   public static void register(IExtension extension) {
/* 11 */     IMixinTransformer transformer = (IMixinTransformer)MixinEnvironment.getDefaultEnvironment().getActiveTransformer();
/* 12 */     Extensions extensions = (Extensions)transformer.getExtensions();
/* 13 */     ExtensionsAccess.getExtensions(extensions).add(0, extension);
/* 14 */     ExtensionsAccess.getExtensionMap(extensions).put(extension.getClass(), extension);
/*    */   }
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\canceller\ExtensionRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */