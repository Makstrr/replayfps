/*    */ package com.bawnorton.mixinsquared.canceller;
/*    */ 
/*    */ import com.bawnorton.mixinsquared.reflection.TargetClassContextAccess;
/*    */ import java.util.SortedSet;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.logging.ILogger;
/*    */ import org.spongepowered.asm.mixin.MixinEnvironment;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.IExtension;
/*    */ import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;
/*    */ import org.spongepowered.asm.service.MixinService;
/*    */ 
/*    */ public final class ExtensionCancelApplication
/*    */   implements IExtension {
/* 15 */   private static final ILogger LOGGER = MixinService.getService().getLogger("mixinsquared");
/*    */ 
/*    */   
/*    */   public boolean checkActive(MixinEnvironment environment) {
/* 19 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void preApply(ITargetClassContext context) {
/* 24 */     SortedSet<IMixinInfo> mixins = TargetClassContextAccess.getMixins(context);
/* 25 */     mixins.removeIf(mixin -> {
/*    */           boolean shouldCancel = MixinCancellerRegistrar.shouldCancel(mixin.getTargetClasses(), mixin.getClassName());
/*    */           if (shouldCancel)
/*    */             LOGGER.debug("Cancelling mixin {}", new Object[] { mixin.getClassName() }); 
/*    */           return shouldCancel;
/*    */         });
/*    */   }
/*    */   
/*    */   public void postApply(ITargetClassContext context) {}
/*    */   
/*    */   public void export(MixinEnvironment env, String name, boolean force, ClassNode classNode) {}
/*    */ }


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\canceller\ExtensionCancelApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */