package com.bawnorton.mixinsquared;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface TargetHandler {
  String name();
  
  String mixin();
  
  String prefix() default "";
  
  boolean print() default false;
}


/* Location:              C:\Users\m_shi\Downloads\replayfps-0.2.0.jar!\META-INF\jars\mixinsquared-fabric-0.1.1.jar!\com\bawnorton\mixinsquared\TargetHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */